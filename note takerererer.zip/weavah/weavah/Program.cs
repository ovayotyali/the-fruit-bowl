﻿
using System;
using System.Collections.Generic;

class Program
{
    static List<Note> notes = new List<Note>();

    static void Main()
    {
        string command;

        do
        {
            Console.Clear();
            Console.WriteLine("Note Taking Application");
            Console.WriteLine("1. Create Note");
            Console.WriteLine("2. View Notes");
            Console.WriteLine("3. Edit Note");
            Console.WriteLine("4. Delete Note");
            Console.WriteLine("5. Exit");
            Console.Write("Choose an option: ");
            command = Console.ReadLine();

            switch (command)
            {
                case "1":
                    CreateNote();
                    break;
                case "2":
                    ViewNotes();
                    break;
                case "3":
                    EditNote();
                    break;
                case "4":
                    DeleteNote();
                    break;
                case "5":
                    Console.WriteLine("Exiting the application...");
                    break;
                default:
                    Console.WriteLine("Invalid option. Please try again.");
                    break;
            }
        } while (command != "5");
    }

    static void CreateNote()
    {
        Console.Clear();
        Console.Write("Enter note title: ");
        string title = Console.ReadLine();
        Console.Write("Enter note content: ");
        string content = Console.ReadLine();
        notes.Add(new Note { Title = title, Content = content });
        Console.WriteLine("Note created successfully! Press any key to continue...");
        Console.ReadKey();
    }

    static void ViewNotes()
    {
        Console.Clear();
        if (notes.Count == 0)
        {
            Console.WriteLine("No notes available. Press any key to continue...");
            Console.ReadKey();
            return;
        }

        Console.WriteLine("Your Notes:");
        for (int i = 0; i < notes.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {notes[i].Title}");
        }

        Console.Write("Press any key to continue...");
        Console.ReadKey();
    }

    static void EditNote()
    {
        Console.Clear();
        ViewNotes();

        Console.Write("Enter the number of the note to edit: ");
        if (int.TryParse(Console.ReadLine(), out int noteNumber) && noteNumber >= 1 && noteNumber <= notes.Count)
        {
            Console.Write("Enter new title: ");
            string newTitle = Console.ReadLine();
            Console.Write("Enter new content: ");
            string newContent = Console.ReadLine();
            notes[noteNumber - 1].Title = newTitle;
            notes[noteNumber - 1].Content = newContent;
            Console.WriteLine("Note updated successfully! Press any key to continue...");
        }
        else
        {
            Console.WriteLine("Invalid note number. Press any key to continue...");
        }
        Console.ReadKey();
    }

    static void DeleteNote()
    {
        Console.Clear();
        ViewNotes();

        Console.Write("Enter the number of the note to delete: ");
        if (int.TryParse(Console.ReadLine(), out int noteNumber) && noteNumber >= 1 && noteNumber <= notes.Count)
        {
            notes.RemoveAt(noteNumber - 1);
            Console.WriteLine("Note deleted successfully! Press any key to continue...");
        }
        else
        {
            Console.WriteLine("Invalid note number. Press any key to continue...");
        }
        Console.ReadKey();
    }
}

class Note
{
    public string Title { get; set; }
    public string Content { get; set; }
}
